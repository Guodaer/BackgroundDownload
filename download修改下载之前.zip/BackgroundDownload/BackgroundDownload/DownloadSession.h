//
//  DownloadSession.h
//  BackgroundDownload
//
//  Created by xiaoyu on 16/6/1.
//  Copyright © 2016年 Damon. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ResponseSession.h"

#define Local_Home_Library_Path ([NSString stringWithFormat:@"%@/Library/Caches",NSHomeDirectory()])



@interface DownloadSession : NSObject

@property (nonatomic, strong)NSString *identifier;

@property (nonatomic, copy) void(^Download_Progress)(double progress);
+ (instancetype) shareInstance;
/**
 *  开始任务
 */
- (void)startDownloadData;
/**
 *  继续下载
 */
- (void)resumeDownload;
/**
 *  停止下载
 */
- (void)stopDownloadData;



@end
