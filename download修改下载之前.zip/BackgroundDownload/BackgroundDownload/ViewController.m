//
//  ViewController.m
//  BackgroundDownload
//
//  Created by xiaoyu on 16/6/1.
//  Copyright © 2016年 Damon. All rights reserved.
//

#import "ViewController.h"
#import "DownloadSession.h"
@interface ViewController () 
{
    UIProgressView *_progress;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//NSLog(@"%@",[[NSProcessInfo processInfo] globallyUniqueString]);
//43284438-629E-4C98-8CEA-01CDE7F851B4-3708-00001F4C6B6F270C
//FDEF2166-4435-4D86-8F44-6C7B321264FE-3735-00001F52DE7A5A8C
//732E8D97-F9FE-4B51-9F73-D470BF73A37D-3759-00001F57912B119E

    [self calumniate];
    
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = CGRectMake(10, 100, 60, 100);
    [button setTitle:@"开始" forState:UIControlStateNormal];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    button.backgroundColor = [UIColor yellowColor];
    [button addTarget:self action:@selector(startdownload) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    
    UIButton *button1 = [UIButton buttonWithType:UIButtonTypeSystem];
    button1.frame = CGRectMake(120, 100, 60, 100);
    [button1 setTitle:@"stop" forState:UIControlStateNormal];
    [button1 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    button1.backgroundColor = [UIColor yellowColor];
    [button1 addTarget:self action:@selector(startdownload1) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button1];

    
    UIButton *button2 = [UIButton buttonWithType:UIButtonTypeSystem];
    button2.frame = CGRectMake(220, 100, 60, 100);
    [button2 setTitle:@"re" forState:UIControlStateNormal];
    [button2 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    button2.backgroundColor = [UIColor yellowColor];
    [button2 addTarget:self action:@selector(startdownload2) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button2];

    _progress = [[UIProgressView alloc] initWithProgressViewStyle:UIProgressViewStyleDefault];
    _progress.progress = 0;
    _progress.frame = CGRectMake(10, 300, CGRectGetWidth(self.view.frame)-20, 10);
    [self.view addSubview:_progress];
    
}
- (void)startdownload2 {
    [[DownloadSession shareInstance] resumeDownload];
    
}
- (void)startdownload1 {
    [[DownloadSession shareInstance] stopDownloadData];

}
- (void)startdownload {
    [[DownloadSession shareInstance] startDownloadData];
    [DownloadSession shareInstance].Download_Progress = ^(double progress){
        dispatch_async(dispatch_get_main_queue(), ^{
            _progress.progress = progress;
        });
    };
}
- (void)calumniate{
    NSString *fileName = @"hello.zip";
    //沙盒
    NSString *path1 = [NSString stringWithFormat:@"%@/Map",Local_Home_Library_Path];
    NSFileManager *manager = [NSFileManager defaultManager];
    BOOL yes;
    if (![manager fileExistsAtPath:path1 isDirectory:&yes]) {
        [manager createDirectoryAtPath:path1 withIntermediateDirectories:YES attributes:nil error:nil];
        
    }
    NSString *savepath = [NSString stringWithFormat:@"%@/%@",path1,fileName];
    NSLog(@"%lld",[self fileSizeForPath:savepath]);
    
}
- (unsigned long long)fileSizeForPath:(NSString *)path {
    
    signed long long fileSize = 0;
    
    NSFileManager *fileManager = [[NSFileManager alloc] init];
    
    if ([fileManager fileExistsAtPath:path]) {
        
        NSError *error = nil;
        
        NSDictionary *fileDict = [fileManager attributesOfItemAtPath:path error:&error];
        
        if (!error && fileDict) {
            
            fileSize = [fileDict fileSize];
        }
    }
    
    return fileSize;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
