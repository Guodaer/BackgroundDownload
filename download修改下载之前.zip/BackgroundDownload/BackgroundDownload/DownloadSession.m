//
//  DownloadSession.m
//  BackgroundDownload
//
//  Created by xiaoyu on 16/6/1.
//  Copyright © 2016年 Damon. All rights reserved.
//

#import "DownloadSession.h"
#import "AppDelegate.h"
#import <UIKit/UIKit.h>
@interface DownloadSession ()<NSURLSessionTaskDelegate,NSURLSessionDownloadDelegate>
{
    NSData *_resumeData;
}
@property (nonatomic, strong) NSURLSession *backgroundSession;

@property (nonatomic, strong) NSURLSessionDownloadTask *backgroundSessionTask;

@end

@implementation DownloadSession
+ (instancetype)shareInstance {
    static DownloadSession *session = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        session = [[self alloc] init];
    });
    return session;
}
- (NSURLSession *)getBackgroundSession:(NSString *)identifier {
    NSURLSession *backgroundSession = nil;
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration backgroundSessionConfigurationWithIdentifier:[NSString stringWithFormat:@"background-NSURLSession-%@",identifier]];
    config.HTTPMaximumConnectionsPerHost = 5;//限制连接到特定主机的数量
    backgroundSession = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    
    return backgroundSession;
}

- (NSURLSession *)backgroundSession{
    if (!_backgroundSession) {
//        NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
//        self.backgroundSession = [NSURLSession sessionWithConfiguration:configuration delegate:self delegateQueue:[NSOperationQueue mainQueue]];
        self.backgroundSession = [self getBackgroundSession:[[NSProcessInfo processInfo] globallyUniqueString]];
    }
    return _backgroundSession;
}
- (void)startDownloadData {
//
//    NSString *urlString = @"http://123.57.25.103/mappkg/1/c0301.zip";
    
    NSString *urlString = @"http://123.57.25.103/mappkg/1/c0103.zip";
    NSURL *url = [NSURL URLWithString:urlString];
    self.backgroundSessionTask = [self.backgroundSession downloadTaskWithURL:url];
    [self.backgroundSessionTask resume];
    
}
- (void)resumeDownload {
    
    if (_resumeData) {
        self.backgroundSessionTask = [self.backgroundSession downloadTaskWithResumeData:_resumeData];
        [self.backgroundSessionTask resume];
        _resumeData = nil;
    }
}
- (void)stopDownloadData{
    
    if (self.backgroundSessionTask) {
        [self.backgroundSessionTask cancelByProducingResumeData:^(NSData * _Nullable resumeData) {
            _resumeData = resumeData;
            
            [[self backgroundSession] finishTasksAndInvalidate];
            self.backgroundSession = nil;
            self.backgroundSessionTask = nil;
        }];
    }
    
}
#pragma mark - NSURLSessionDownloadDelegate 代理方法
- (void)URLSession:(NSURLSession *)session downloadTask:(NSURLSessionDownloadTask *)downloadTask didFinishDownloadingToURL:(NSURL *)location{

    NSString *fileName = @"hello.zip";
    //沙盒
    NSString *path1 = [NSString stringWithFormat:@"%@/Map",Local_Home_Library_Path];
    NSFileManager *manager = [NSFileManager defaultManager];
    BOOL yes;
    if (![manager fileExistsAtPath:path1 isDirectory:&yes]) {
        BOOL b = [manager createDirectoryAtPath:path1 withIntermediateDirectories:YES attributes:nil error:nil];
        NSLog(@"%d",b);
    }
    NSString *savepath = [NSString stringWithFormat:@"%@/%@",path1,fileName];
    [[NSFileManager defaultManager] removeItemAtPath:savepath error:nil];
    //将文件从历史文件夹复制到沙盒
    BOOL b1 = [[NSFileManager defaultManager] copyItemAtPath:location.path toPath:savepath error:nil];
    BOOL b2=[[NSFileManager defaultManager] removeItemAtURL:location error:nil];
    NSLog(@"%d-%d",b1,b2);
    
    AppDelegate *deledate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    if (deledate.backgroundURLSessionCompletionHandler) {
        void (^handler)() = deledate.backgroundURLSessionCompletionHandler;
        deledate.backgroundURLSessionCompletionHandler = nil;
        handler();
        NSLog(@"后台下载完成");
        if (self.Download_Progress) {
            self.Download_Progress(1);
        }
        [self showLocalNotification:YES];
//        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Finish" message:nil delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
//        [alert show];
        
        
    }
    
}
- (void)showLocalNotification:(BOOL)downloadSuc {
    UILocalNotification *notification = [[UILocalNotification alloc] init];
    if (notification!=nil) {
        
        NSDate *now=[NSDate new];
        notification.fireDate=[now dateByAddingTimeInterval:6]; //触发通知的时间
        notification.repeatInterval = 0; //循环次数，kCFCalendarUnitWeekday一周一次
        
        notification.timeZone = [NSTimeZone defaultTimeZone];
        notification.soundName = UILocalNotificationDefaultSoundName;
        notification.alertBody = downloadSuc ? @"后台下载成功啦" : @"下载失败";
        notification.alertAction = @"打开";  //提示框按钮
        notification.hasAction = YES; //是否显示额外的按钮，为no时alertAction消失
        notification.applicationIconBadgeNumber = 1; //设置app图标右上角的数字
        
        //下面设置本地通知发送的消息，这个消息可以接受
        NSDictionary* infoDic = [NSDictionary dictionaryWithObject:@"value" forKey:@"key"];
        notification.userInfo = infoDic;
        //发送通知
        [[UIApplication sharedApplication] scheduleLocalNotification:notification];
    }
}

- (void)URLSession:(NSURLSession *)session downloadTask:(NSURLSessionDownloadTask *)downloadTask didWriteData:(int64_t)bytesWritten totalBytesWritten:(int64_t)totalBytesWritten totalBytesExpectedToWrite:(int64_t)totalBytesExpectedToWrite{

    double progress = (double)totalBytesWritten/(double)totalBytesExpectedToWrite;
    if (self.Download_Progress) {
        self.Download_Progress(progress);
    }
}
- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task didCompleteWithError:(NSError *)error{
//成功或失败都会调用一下的
    NSLog(@"didCompleteWithError--%@",error);
}

/*
 当不再需要连接时，可以调用Session的invalidateAndCancel直接关闭，或者调用finishTasksAndInvalidate等待当前Task结束后关闭。这时Delegate会收到URLSession:didBecomeInvalidWithError:这个事件
 */
- (void)URLSession:(NSURLSession *)session didBecomeInvalidWithError:(NSError *)error{
    NSLog(@"didBecomeInvalidWithError");
}

- (void)URLSessionDidFinishEventsForBackgroundURLSession:(NSURLSession *)session {
    NSLog(@"URLSessionDidFinishEventsForBackgroundURLSession");
}



/**
 *  下面是没用的东西 *********************
 */

- (void)startDownloadData1 {

    NSString *urlString = @"http://123.57.25.103/mappkg/1/c0301.zip";
    NSURL *url = [NSURL URLWithString:urlString];
    NSURLRequest *request = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:5];
    _backgroundSession = [NSURLSession sharedSession];
    
    _backgroundSessionTask = [_backgroundSession downloadTaskWithRequest:request completionHandler:^(NSURL * _Nullable location, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (error) {
            NSLog(@"error---%@",error);
        }
        NSLog(@"%@",location);
        NSString *fileName = [urlString lastPathComponent];
        //沙盒
        NSArray *docs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *path = [docs[0] stringByAppendingPathComponent:fileName];
        NSURL *toURL = [NSURL fileURLWithPath:path];
        
        //将文件从历史文件夹复制到沙盒
        [[NSFileManager defaultManager] copyItemAtURL:location toURL:toURL error:nil];
        
        unsigned long long downloadedBytes = 0;
        downloadedBytes = [self fileSizeForPath:path];
        NSLog(@"%llu",downloadedBytes);

    }];
    [_backgroundSessionTask resume];

}


- (unsigned long long)fileSizeForPath:(NSString *)path {
    
    signed long long fileSize = 0;
    
    NSFileManager *fileManager = [[NSFileManager alloc] init];
    
    if ([fileManager fileExistsAtPath:path]) {
        
        NSError *error = nil;
        
        NSDictionary *fileDict = [fileManager attributesOfItemAtPath:path error:&error];
        
        if (!error && fileDict) {
            
            fileSize = [fileDict fileSize];
        }
    }
    
    return fileSize;
}


@end


